#!/usr/bin/python

''' --- Function of mapping --- '''
# text : string containing the text to map
def map(text):

    # dictionnary variable to contain the mapped text
    mapped_text = {}

    # remove all the non word characters component 
    for character in ['.',',',';',':','!','?','"']:
	text = text.replace(character,'')

    # put all the capital letter of words into lower
    lowered_text = text.lower()

    # fill an array with all words of the text
    split_text = lowered_text.split()

    # fill the dictionnary with the words as keys
    # and arrays of ocurrences [1,1,...] as values
    for word in split_text:
	# if the key already exists
        if mapped_text.has_key(word):
	    # add an occurence in the array
            mapped_text[word].append(1)
        else:
	    # create a new entry in the dictionnary
	    tmp = {word:[1]}
            mapped_text.update(tmp)

    return mapped_text
''' --- End function of mapping --- '''

''' --- Funtion of sorting --- '''
# mapped_text : dictionnary containing a mapped text
def sort(mapped_text):

    # array variable to contain the sorted text
    sorted_text = []
    # transition variable of a key of the dictionnary
    key_value = ""
    # transition variable of a value of the dictionnary
    value_key = []

    # while there is an element left in the dictionnary
    while len(mapped_text) > 0:
	# the first element of the dictionnary is assigned
	# as a reference for beginning the sorting
        key_val = mapped_text.keys()[0]
	val_key = mapped_text[key_val]

	# foreach word in the dictionnary
        for key in mapped_text.keys():
	    # if the current word is different from 
	    # the one used as a reference
            if key != key_val:
		# if the current word is before the one 
		# stored in the alphabetical order
		if key_val != min(key, key_val):
		    # then assign the current word and the array
		    # of its ocurrences to the transition variable
		    key_val = key
		    val_key = mapped_text[key]

	# add the word and the array of its occurences 
	# to the array of new structure of data
        sorted_text.append({key_val: val_key})
	# delete the word added from the old structure
	# to not test it again
        mapped_text.pop(key_val)

    return sorted_text
''' --- End function of sorting --- '''

''' --- Function of reducing --- '''
# sorted_text : array containing a set of {key:[1,1,1,...]}
def reduce(sorted_text):

    # array variable to contain the reduced text
    reduced_text = []
    # variable to contain a key of the parameter
    key = ""
    # variable to contain the length of the array of occurences
    value = 0

    # foreach key-value couple in the parameter
    for value in sorted_text:
	# get and assign the value of the key
        key = value.keys()[0]
	# get and assign the value of the length of the array
        value = len(value.values()[0])
	# add the new key-value couple to the new data structure
        reduced_text.append({key: value})

    return reduced_text
''' --- End function of reducing --- '''


''' --- START OF THE PROGRAM --- '''

print "\n--- The original text ---"
# open the get the content of 'test.txt'
text = open("text.txt").read()
print text
print "-------------------------\n"

print "---- The mapped text ----"
mapped_text = map(text)
print mapped_text
print "-------------------------\n"

print "---- The sorted text ----"
sorted_text = sort(mapped_text)
print sorted_text
print "-------------------------\n"

print "--- The reduced text ----"
reduced_text = reduce(sorted_text)
print reduced_text
print "-------------------------\n"

''' --- END OF THE PROGRAM --- '''
